---
permalink: /
title: "André Nascimento"
excerpt: "About me"
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---

BSc in Computer Enginnering (UPE, Brazil), MSc and PhD in Machine Learning (UFPE, Brazil), currently working as adjunct professor at Universidade Federal Rural de Pernambuco ([UFRPE](http://www.ufrpe.br)), Departamento de Computação ([DC](http://dc.ufrpe.br)). Main areas of expertise: kernel methods, text mining and computational biology.

Research Interests
======
- Machine Learning 
- Kernel Methods
- Meta-learning
- Computational Biology
- Systems Biology
- Recommender Systems


